# Spotify_Clone
I developed a spotify clone website which plays songs.
Technologies used : HTML5, CSS3, JAVASCRIPT.
